#!/usr/bin/env python3
"""Isolated mock test suite for RedVector Scan Plugin v0.2.0-dev.

Drives the adapter AS A SUBPROCESS over stdio with JSON-RPC. Any backend HTTP
goes to a throwaway loopback MOCK server (a TEST FIXTURE, explicitly NOT the
real RedVector backend and NOT nmap). Performs NO real network scan, starts no
service, installs nothing. Exit code 0 only if every check passes.
"""
import json
import os
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ADAPTER = os.path.join(os.path.dirname(HERE), "adapter", "redvector_scan_adapter.py")
PYEXE = sys.executable
TEST_TOKEN = "unit-test-token-NOTREAL"   # fixture credential, never a real token

_SCAN_ENV = ("REDVECTOR_HOST", "REDVECTOR_PORT", "REDVECTOR_DIAG_TIMEOUT",
             "REDVECTOR_SCAN_TIMEOUT", "REDVECTOR_API_TOKEN", "REDVECTOR_SCAN_SCOPE",
             "REDVECTOR_SCAN_SCOPE_FILE", "REDVECTOR_SCAN_MAX_HOSTS")

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append(bool(ok))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))


def run_adapter(lines, env_extra=None, timeout=20):
    env = dict(os.environ)
    for k in _SCAN_ENV:
        env.pop(k, None)
    if env_extra:
        env.update({k: str(v) for k, v in env_extra.items()})
    stdin = "".join(l + "\n" for l in lines)
    t0 = time.time()
    p = subprocess.run([PYEXE, ADAPTER], input=stdin, env=env,
                       capture_output=True, text=True, timeout=timeout)
    elapsed = time.time() - t0
    out = []
    for ln in p.stdout.splitlines():
        ln = ln.strip()
        if ln:
            try:
                out.append(json.loads(ln))
            except ValueError:
                out.append({"_unparsed": ln})
    return out, elapsed, p.stdout, p.stderr


def by_id(resps):
    return {r.get("id"): r for r in resps if isinstance(r, dict)}


def payload(resp):
    if not resp or "result" not in resp:
        return None
    return resp["result"].get("structuredContent")


def rpc(i, method, params=None):
    m = {"jsonrpc": "2.0", "id": i, "method": method}
    if params is not None:
        m["params"] = params
    return json.dumps(m)


def scan_call(i, args):
    return rpc(i, "tools/call", {"name": "scan_tcp_ports", "arguments": args})


# --------------------------------------------------------------------------
# Mock backend fixture
# --------------------------------------------------------------------------
class MockBackend(BaseHTTPRequestHandler):
    mode = "healthy"
    requests = []

    def log_message(self, *a):
        pass

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            body = json.loads(raw.decode("utf-8"))
        except ValueError:
            body = None
        MockBackend.requests.append({
            "path": self.path,
            "auth": self.headers.get("Authorization"),
            "ctype": self.headers.get("Content-Type"),
            "body": body,
        })
        m = MockBackend.mode
        if m == "auth_fail":
            self.send_response(401); self.end_headers(); self.wfile.write(b'{"error":"Unauthorized"}'); return
        if m == "server_error":
            self.send_response(500); self.end_headers(); self.wfile.write(b'{"error":"boom"}'); return
        if m == "malformed":
            self.send_response(200); self.send_header("Content-Type", "application/json")
            self.end_headers(); self.wfile.write(b'not-json<<<'); return
        if m == "slow":
            time.sleep(3)
        if m == "timed_out":
            resp = {"success": False, "timed_out": True, "partial_results": True,
                    "return_code": None, "execution_time": 120.0, "stdout": "",
                    "parsed": {"target": "", "hosts": [], "open_ports": [], "services": [],
                               "os_detection": "", "scan_summary": ""}}
        else:  # healthy
            resp = {"success": True, "timed_out": False, "partial_results": False,
                    "return_code": 0, "execution_time": 1.5,
                    "stdout": "Nmap scan report ...",
                    "parsed": {"target": "127.0.0.1", "hosts": ["127.0.0.1"],
                               "open_ports": [
                                   {"port": "22", "protocol": "tcp", "state": "open",
                                    "service": "ssh OpenSSH 9.6p1"},
                                   {"port": "80", "protocol": "tcp", "state": "open",
                                    "service": "http nginx 1.25.3"}],
                               "services": ["22/tcp -> ssh OpenSSH 9.6p1",
                                            "80/tcp -> http nginx 1.25.3"],
                               "os_detection": "", "scan_summary": "Nmap done: 1 IP address"}}
        data = json.dumps(resp).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers()
        self.wfile.write(data)


def start_mock():
    srv = HTTPServer(("127.0.0.1", 0), MockBackend)
    port = srv.server_address[1]
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    return srv, port


UNUSED = 9  # discard port -> instant connection refusal


# ==========================================================================
print("\n===== 10.1 MCP PROTOCOL =====")
reqs = [
    rpc(1, "initialize", {"protocolVersion": "2025-06-18", "capabilities": {}}),
    rpc(2, "tools/list"),
    rpc(3, "tools/call", {"name": "evil_tool"}),
    rpc(4, "tools/call", {"name": "nmap_scan"}),                       # not in allowlist
    scan_call(5, {"target": "127.0.0.1", "authorized": True, "bogus": 1}),  # unsupported arg
    rpc(6, "tools/call", {"name": "scan_tcp_ports", "arguments": "x"}),     # non-object args
    "{ broken json",
    rpc(7, "ping"),
    rpc(8, "no/such/method"),
]
resps, _, _, _ = run_adapter(reqs, {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED})
m = by_id(resps)
check("initialize serverInfo name=redvector-scan-dev",
      m.get(1, {}).get("result", {}).get("serverInfo", {}).get("name") == "redvector-scan-dev")
tools = m.get(2, {}).get("result", {}).get("tools", [])
names = sorted(t.get("name") for t in tools)
check("tools/list = exactly 3 diagnostics + scan_tcp_ports",
      names == ["backend_health", "backend_version", "scan_tcp_ports", "service_status"], str(names))
diag = {t["name"]: t for t in tools if t["name"] != "scan_tcp_ports"}
check("diagnostics remain readOnlyHint:true",
      all(diag[n]["annotations"].get("readOnlyHint") is True for n in diag))
scan = next(t for t in tools if t["name"] == "scan_tcp_ports")
check("scan_tcp_ports schema requires target+authorized, additionalProperties:false",
      scan["inputSchema"]["required"] == ["target", "authorized"]
      and scan["inputSchema"]["additionalProperties"] is False)
check("scan_tcp_ports is not advertised read-only",
      scan["annotations"].get("readOnlyHint") is False)
check("unknown tool -> -32601", m.get(3, {}).get("error", {}).get("code") == -32601)
check("non-allowlisted real tool name -> -32601", m.get(4, {}).get("error", {}).get("code") == -32601)
check("unsupported scan argument -> -32602", m.get(5, {}).get("error", {}).get("code") == -32602)
check("non-object arguments -> -32602", m.get(6, {}).get("error", {}).get("code") == -32602)
parse_err = [r for r in resps if r.get("id") is None and r.get("error", {}).get("code") == -32700]
check("malformed JSON -> -32700", len(parse_err) == 1)
check("ping -> {}", m.get(7, {}).get("result") == {})
check("unknown method -> -32601", m.get(8, {}).get("error", {}).get("code") == -32601)


print("\n===== 10.4 DIAGNOSTIC REGRESSION (identical to v0.1.0) =====")
resps, _, _, _ = run_adapter([
    rpc(1, "tools/call", {"name": "backend_health"}),
    rpc(2, "tools/call", {"name": "service_status"}),
    rpc(3, "tools/call", {"name": "backend_version"}),
], {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED})
m = by_id(resps)
check("backend_health available=false/unreachable",
      payload(m.get(1)) == {"available": False, "detail": "unreachable"}, str(payload(m.get(1))))
sp = payload(m.get(2))
check("service_status configured=true reachable=false",
      sp and sp.get("configured") is True and sp.get("reachable") is False, str(sp))
check("backend_version unknown when down", payload(m.get(3)) == {"version": "unknown"})
# not configured
resps, _, _, _ = run_adapter([rpc(1, "tools/call", {"name": "service_status"})],
                             {"REDVECTOR_HOST": "127.0.0.1"})
check("service_status configured=false when no port",
      (payload(by_id(resps).get(1)) or {}).get("configured") is False)


print("\n===== 10.2 AUTHORIZATION / SCOPE (fail-closed; no real scans) =====")
SCOPE = "127.0.0.0/8"


def scan_once(args, env_extra, _id=1):
    resps, el, _, _ = run_adapter([scan_call(_id, args)], env_extra)
    return payload(by_id(resps).get(_id)), el


# scope not configured -> reject (even with authorized + token)
r, _ = scan_once({"target": "127.0.0.1", "authorized": True},
                 {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN})
check("no scope configured -> rejected(config)", r and r.get("status") == "rejected" and r.get("category") == "config", str(r))
# authorized missing -> reject
r, _ = scan_once({"target": "127.0.0.1"},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("authorized missing -> rejected(authorization)", r and r.get("category") == "authorization", str(r))
# authorized false -> reject
r, _ = scan_once({"target": "127.0.0.1", "authorized": False},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("authorized=false -> rejected(authorization)", r and r.get("category") == "authorization", str(r))
# shell injection target -> validation reject
r, _ = scan_once({"target": "127.0.0.1; rm -rf /", "authorized": True},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("shell-injection target -> rejected(validation)", r and r.get("category") == "validation", str(r))
# command-substitution target -> validation reject
r, _ = scan_once({"target": "$(reboot)", "authorized": True},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("cmd-substitution target -> rejected(validation)", r and r.get("category") == "validation", str(r))
# out of scope
r, _ = scan_once({"target": "8.8.8.8", "authorized": True},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("out-of-scope IPv4 -> rejected(scope)", r and r.get("category") == "scope", str(r))
# CIDR too large
r, _ = scan_once({"target": "10.0.0.0/8", "authorized": True},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN,
                  "REDVECTOR_SCAN_SCOPE": "10.0.0.0/8", "REDVECTOR_SCAN_MAX_HOSTS": 256})
check("oversized CIDR -> rejected(scope)", r and r.get("category") == "scope", str(r))
# in-scope CIDR within limit passes scope (then backend unreachable on UNUSED)
r, _ = scan_once({"target": "127.0.0.0/30", "authorized": True},
                 {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED,
                  "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("in-scope small CIDR passes gate (reaches backend)", r and r.get("status") == "backend_unreachable", str(r))
# IPv6 validation + scope
r, _ = scan_once({"target": "2001:db8::1", "authorized": True},
                 {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED,
                  "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": "2001:db8::/32"})
check("in-scope IPv6 passes gate", r and r.get("status") == "backend_unreachable", str(r))
# IP-only initial-lab policy: hostname target rejected by default (item 7)
r, _ = scan_once({"target": "localhost", "authorized": True},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN,
                  "REDVECTOR_SCAN_SCOPE": "127.0.0.0/8 localhost"})
check("hostname disabled by default -> rejected(policy)", r and r.get("category") == "policy", str(r))
# With explicit opt-in, DNS scope enforcement applies:
HN = {"REDVECTOR_SCAN_ALLOW_HOSTNAMES": 1}
# localhost resolves to loopback, scope excludes loopback
r, _ = scan_once({"target": "localhost", "authorized": True},
                 dict({"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN,
                       "REDVECTOR_SCAN_SCOPE": "192.0.2.0/24 localhost"}, **HN))
check("hostname resolving outside scope -> rejected(scope)", r and r.get("category") == "scope", str(r))
# hostname not listed -> reject
r, _ = scan_once({"target": "localhost", "authorized": True},
                 dict({"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN,
                       "REDVECTOR_SCAN_SCOPE": "127.0.0.0/8"}, **HN))
check("hostname not in name allowlist -> rejected(scope)", r and r.get("category") == "scope", str(r))
# unresolvable hostname -> reject
r, _ = scan_once({"target": "nonexistent.invalid", "authorized": True},
                 dict({"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN,
                       "REDVECTOR_SCAN_SCOPE": "127.0.0.0/8 nonexistent.invalid"}, **HN))
check("unresolvable hostname -> rejected(scope)", r and r.get("category") == "scope", str(r))
# token missing -> backend-auth-config (scope ok, authorized, in scope)
r, _ = scan_once({"target": "127.0.0.1", "authorized": True},
                 {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("missing token -> rejected(backend-auth-config)", r and r.get("category") == "backend-auth-config", str(r))
# dev-token fallback refused
r, _ = scan_once({"target": "127.0.0.1", "authorized": True},
                 {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED,
                  "REDVECTOR_API_TOKEN": "redvector-dev-token", "REDVECTOR_SCAN_SCOPE": SCOPE})
check("dev-token refused -> rejected(backend-auth-config)", r and r.get("category") == "backend-auth-config", str(r))
# invalid ports
r, _ = scan_once({"target": "127.0.0.1", "authorized": True, "ports": "80;443"},
                 {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": UNUSED,
                  "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": SCOPE})
check("invalid ports -> rejected(validation)", r and r.get("category") == "validation", str(r))


print("\n===== 10.3 BACKEND INTEGRATION (mock fixture) =====")
srv, port = start_mock()
try:
    base_env = {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": port,
                "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": "127.0.0.0/8"}
    # healthy
    MockBackend.mode = "healthy"; MockBackend.requests = []
    r, _ = scan_once({"target": "127.0.0.1", "authorized": True, "ports": "22,80"}, base_env)
    check("completed status", r and r.get("status") == "completed", str(r and r.get("status")))
    check("evidence=backend-execution", r and r.get("evidence") == "backend-execution")
    check("open ports extracted (2)", r and len(r.get("open_ports", [])) == 2, str(r and r.get("open_ports")))
    check("service/version surfaced", r and any("OpenSSH" in s for s in r.get("services", [])))
    req = MockBackend.requests[-1] if MockBackend.requests else {}
    check("correct backend route POST /api/tools/nmap", req.get("path") == "/api/tools/nmap")
    check("Authorization Bearer token sent", req.get("auth") == "Bearer " + TEST_TOKEN)
    check("request reused existing schema (scan_type=-sV, ports passthrough)",
          req.get("body", {}).get("scan_type") == "-sV" and req.get("body", {}).get("ports") == "22,80",
          str(req.get("body")))
    check("adapter did not send a shell/additional_args payload",
          req.get("body", {}).get("additional_args") == "")
    # auth fail
    MockBackend.mode = "auth_fail"
    r, _ = scan_once({"target": "127.0.0.1", "authorized": True}, base_env)
    check("backend 401 -> backend_auth_failed", r and r.get("status") == "backend_auth_failed", str(r and r.get("status")))
    # server error
    MockBackend.mode = "server_error"
    r, _ = scan_once({"target": "127.0.0.1", "authorized": True}, base_env)
    check("backend 500 -> backend_error", r and r.get("status") == "backend_error")
    # malformed
    MockBackend.mode = "malformed"
    r, _ = scan_once({"target": "127.0.0.1", "authorized": True}, base_env)
    check("malformed body -> backend_malformed_response", r and r.get("status") == "backend_malformed_response")
    # timed out fixture
    MockBackend.mode = "timed_out"
    r, _ = scan_once({"target": "127.0.0.1", "authorized": True}, base_env)
    check("timed_out fixture -> scan_timed_out", r and r.get("status") == "scan_timed_out", str(r and r.get("status")))
    # slow -> client timeout
    MockBackend.mode = "slow"
    r, el = scan_once({"target": "127.0.0.1", "authorized": True}, dict(base_env, REDVECTOR_SCAN_TIMEOUT=1))
    check("slow backend -> unreachable within timeout", r and r.get("status") == "backend_unreachable" and el < 3.0,
          f"{r and r.get('status')} in {el:.2f}s")
    # no unauthorized backend request: out-of-scope target makes zero backend calls
    MockBackend.mode = "healthy"; MockBackend.requests = []
    r, _ = scan_once({"target": "8.8.8.8", "authorized": True}, base_env)
    check("unauthorized target -> NO backend request made",
          r and r.get("category") == "scope" and len(MockBackend.requests) == 0, str(len(MockBackend.requests)))
finally:
    srv.shutdown()


print("\n===== 10.5 SECURITY REGRESSION =====")
import ast
src = open(ADAPTER, encoding="utf-8").read()
tree = ast.parse(src)
imported = set()
for n in ast.walk(tree):
    if isinstance(n, ast.Import):
        imported.update(a.name.split(".")[0] for a in n.names)
    elif isinstance(n, ast.ImportFrom) and n.module:
        imported.add(n.module.split(".")[0])
check("adapter does NOT import subprocess", "subprocess" not in imported)
bad = []
for n in ast.walk(tree):
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute):
        v = n.func.value
        if isinstance(v, ast.Name) and v.id == "subprocess":
            bad.append("subprocess." + n.func.attr)
        if isinstance(v, ast.Name) and v.id == "os" and n.func.attr in {"system", "popen", "execv", "execl"}:
            bad.append("os." + n.func.attr)
check("adapter makes no process-exec calls", bad == [], str(bad))
# tools/list exposes no offensive tool
resps, _, _, _ = run_adapter([rpc(1, "tools/list")], {"REDVECTOR_PORT": UNUSED})
tl = sorted(t["name"] for t in by_id(resps).get(1, {}).get("result", {}).get("tools", []))
OFFENSIVE = {"execute_command", "metasploit_run", "mimikatz_execute", "reverse_shell_generate",
             "delete_file", "generate_payload", "sqlmap_scan"}
check("no offensive tools exposed", not (set(tl) & OFFENSIVE), str(tl))
check("exactly 4 tools exposed", len(tl) == 4, str(tl))
# token never leaked in a completed scan result
srv, port = start_mock()
try:
    MockBackend.mode = "healthy"
    resps, _, stdout, _ = run_adapter(
        [scan_call(1, {"target": "127.0.0.1", "authorized": True})],
        {"REDVECTOR_HOST": "127.0.0.1", "REDVECTOR_PORT": port,
         "REDVECTOR_API_TOKEN": TEST_TOKEN, "REDVECTOR_SCAN_SCOPE": "127.0.0.0/8"})
    check("API token never appears in adapter stdout", TEST_TOKEN not in stdout)
finally:
    srv.shutdown()
# fail-closed default: no scope env anywhere -> rejected(config), proves no baked-in scope
r, _ = scan_once({"target": "192.0.2.5", "authorized": True},
                 {"REDVECTOR_PORT": UNUSED, "REDVECTOR_API_TOKEN": TEST_TOKEN})
check("no hardcoded scope default (fail closed)", r and r.get("category") == "config", str(r))
check("adapter source contains no '0.0.0.0/0' default", "0.0.0.0/0" not in src)


print("\n===== SUMMARY =====")
passed = sum(1 for ok in RESULTS if ok)
print(f"{passed}/{len(RESULTS)} checks passed")
sys.exit(0 if passed == len(RESULTS) else 1)
