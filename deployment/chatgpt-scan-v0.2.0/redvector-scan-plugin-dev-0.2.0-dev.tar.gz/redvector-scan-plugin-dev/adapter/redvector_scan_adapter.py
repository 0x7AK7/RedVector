#!/usr/bin/env python3
# ============================================================================
#  RedVector Scan Plugin v0.2.0-dev  -  isolated, additive MCP stdio adapter
# ----------------------------------------------------------------------------
#  DEVELOPMENT build. NOT installed/activated by this package.
#
#  Exposes the THREE preserved read-only diagnostic tools (identical contracts
#  and behavior to the installed v0.1.0 plugin):
#      - backend_health, service_status, backend_version
#  plus ONE new, reviewed, additive capability:
#      - scan_tcp_ports : authorized TCP port + service/version scan, executed
#        by RedVector's EXISTING backend endpoint (POST /api/tools/nmap).
#
#  Security model (ENFORCED IN CODE):
#    * Hard exact-name allowlist of exactly four tools; anything else is
#      rejected (fail closed). No offensive/credential/exploit tools exposed.
#    * The adapter NEVER runs nmap or any shell/subprocess itself. It only
#      performs HTTP to a VALIDATED loopback backend. No second scanning engine.
#    * scan_tcp_ports enforces, on EVERY request and fail-closed:
#        - approved scan scope must be configured (else reject),
#        - explicit per-request authorization flag,
#        - strict target syntax validation (IPv4/IPv6/hostname/CIDR only;
#          rejects shell/argument-injection characters),
#        - CIDR size limit,
#        - scope membership incl. DNS resolution checks for hostnames
#          (every resolved IP must be in scope; prevents DNS-rebinding bypass),
#        - backend bearer token must be configured (dev-token fallback refused).
#    * Backend host/port/token come ONLY from documented environment variables;
#      nothing is hardcoded. Tokens are never logged or returned.
#    * Returns genuine backend results only; never fabricates ports/services.
#
#  Pure Python standard library only. No third-party dependencies.
# ============================================================================
from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
import sys
import urllib.error
import urllib.request
from urllib.parse import urlsplit

SERVER_NAME = "redvector-scan-dev"
SERVER_VERSION = "0.2.0-dev"
DEFAULT_PROTOCOL_VERSION = "2025-06-18"

# Diagnostic timeout (preserved from v0.1.0 behavior).
try:
    HTTP_TIMEOUT = max(0.5, min(10.0, float(os.environ.get("REDVECTOR_DIAG_TIMEOUT", "3"))))
except (TypeError, ValueError):
    HTTP_TIMEOUT = 3.0

# Separate, bounded timeout for a scan request to the backend (seconds).
try:
    SCAN_TIMEOUT = max(1.0, min(600.0, float(os.environ.get("REDVECTOR_SCAN_TIMEOUT", "120"))))
except (TypeError, ValueError):
    SCAN_TIMEOUT = 120.0

ALLOWED_TOOLS = ("backend_health", "service_status", "backend_version", "scan_tcp_ports")
_SCAN_ARGS = {"target", "ports", "authorized"}

_MAX_BODY_BYTES = 65536
_MAX_SCAN_BODY_BYTES = 1024 * 1024
_BACKEND_ENDPOINT = "/api/tools/nmap"   # existing, verified backend route (reused)

# Adapter-fixed, non-user-controlled scan options (service/version detection).
# These mirror the existing nmap_scan MCP tool defaults; target & ports are the
# only user-influenced fields and are both strictly validated.
_SCAN_TYPE = "-sV"
_ADDITIONAL_ARGS = ""
_USE_RECOVERY = True


# --------------------------------------------------------------------------
# Configuration discovery (shared; no hardcoded port; loopback-only backend)
# --------------------------------------------------------------------------
def _resolve_target():
    host = (os.environ.get("REDVECTOR_HOST", "") or "127.0.0.1").strip() or "127.0.0.1"
    raw = (os.environ.get("REDVECTOR_PORT", "") or "").strip()
    port = None
    if raw.isdigit():
        value = int(raw)
        if 1 <= value <= 65535:
            port = value
    return host, port


def _is_loopback(host):
    if not host:
        return False
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _is_ipv6(host):
    try:
        return ipaddress.ip_address(host).version == 6
    except ValueError:
        return False


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _loopback_get(path):
    host, port = _resolve_target()
    if port is None:
        return (False, None, "backend port not configured (set REDVECTOR_PORT)")
    if not _is_loopback(host):
        return (False, None, "refused: destination host is not loopback")
    netloc_host = "[{0}]".format(host) if _is_ipv6(host) else host
    url = "http://{0}:{1}{2}".format(netloc_host, port, path)
    parts = urlsplit(url)
    if parts.scheme != "http" or not _is_loopback(parts.hostname or ""):
        return (False, None, "refused: non-loopback or non-http destination")
    opener = urllib.request.build_opener(_NoRedirect)
    request = urllib.request.Request(url, method="GET")  # no auth header set
    try:
        with opener.open(request, timeout=HTTP_TIMEOUT) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            text = resp.read(_MAX_BODY_BYTES).decode("utf-8", "replace")
            return (True, status, text)
    except urllib.error.HTTPError as exc:
        return (True, exc.code, "")
    except (urllib.error.URLError, socket.timeout, OSError):
        return (False, None, "unreachable")


def _loopback_post(path, payload, token):
    """Authenticated loopback-only POST. Token is sent only as a Bearer header
    and never logged or returned. Follows no redirects."""
    host, port = _resolve_target()
    if port is None:
        return (False, None, "backend port not configured (set REDVECTOR_PORT)")
    if not _is_loopback(host):
        return (False, None, "refused: destination host is not loopback")
    netloc_host = "[{0}]".format(host) if _is_ipv6(host) else host
    url = "http://{0}:{1}{2}".format(netloc_host, port, path)
    parts = urlsplit(url)
    if parts.scheme != "http" or not _is_loopback(parts.hostname or ""):
        return (False, None, "refused: non-loopback or non-http destination")
    body = json.dumps(payload).encode("utf-8")
    opener = urllib.request.build_opener(_NoRedirect)
    request = urllib.request.Request(url, data=body, method="POST")
    request.add_header("Content-Type", "application/json")
    request.add_header("Authorization", "Bearer " + token)
    try:
        with opener.open(request, timeout=SCAN_TIMEOUT) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            text = resp.read(_MAX_SCAN_BODY_BYTES).decode("utf-8", "replace")
            return (True, status, text)
    except urllib.error.HTTPError as exc:
        text = ""
        try:
            text = exc.read(4096).decode("utf-8", "replace")
        except Exception:
            text = ""
        return (True, exc.code, text)
    except (urllib.error.URLError, socket.timeout, OSError):
        return (False, None, "unreachable")


def _loopback_tcp_open(host, port):
    if not _is_loopback(host):
        return False
    try:
        with socket.create_connection((host, port), timeout=HTTP_TIMEOUT):
            return True
    except (OSError, socket.timeout):
        return False


def _health_json(text):
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        return None
    return data if isinstance(data, dict) else None


# --------------------------------------------------------------------------
# Preserved diagnostic tools (identical to v0.1.0)
# --------------------------------------------------------------------------
def tool_backend_health():
    ok, status, text = _loopback_get("/health")
    if not ok:
        return {"available": False, "detail": text}
    body = _health_json(text) or {}
    reported = body.get("status")
    status_str = reported if isinstance(reported, str) and len(reported) <= 32 else None
    result = {"available": status == 200, "http_status": status}
    if status_str:
        result["status"] = status_str
    return result


def tool_service_status():
    host, port = _resolve_target()
    if port is None:
        return {"configured": False, "detail": "REDVECTOR_PORT is not set"}
    if not _is_loopback(host):
        return {"configured": True, "reachable": False, "detail": "non-loopback host refused"}
    return {"configured": True, "host": host, "port": port,
            "reachable": _loopback_tcp_open(host, port)}


def tool_backend_version():
    ok, status, text = _loopback_get("/health")
    if ok and status == 200:
        body = _health_json(text) or {}
        value = body.get("version")
        if isinstance(value, str) and 0 < len(value) <= 64:
            return {"version": value, "source": "/health"}
    return {"version": "unknown"}


DIAG_HANDLERS = {
    "backend_health": tool_backend_health,
    "service_status": tool_service_status,
    "backend_version": tool_backend_version,
}


# --------------------------------------------------------------------------
# scan_tcp_ports: validation, fail-closed scope gate, backend call, mapping
# --------------------------------------------------------------------------
_HOST_RE = re.compile(
    r"^(?=.{1,253}$)([A-Za-z0-9_](?:[A-Za-z0-9_-]{0,62})?)"
    r"(\.[A-Za-z0-9_](?:[A-Za-z0-9_-]{0,62})?)*$")
_TARGET_CHARS = re.compile(r"^[A-Za-z0-9.\-:/]+$")   # rejects spaces & shell metachars
_PORTS_RE = re.compile(r"^\d{1,5}(-\d{1,5})?(,\d{1,5}(-\d{1,5})?)*$")


def _reject(category, detail):
    return {"status": "rejected", "authorized": False, "category": category,
            "detail": detail, "open_ports": [], "services": [],
            "evidence": "no-backend-request"}


def _valid_hostname(h):
    if _looks_ip(h):
        return False
    return bool(_HOST_RE.match(h))


def _looks_ip(h):
    try:
        ipaddress.ip_address(h)
        return True
    except ValueError:
        return False


def _valid_ports(p):
    if not _PORTS_RE.match(p):
        return False
    for part in p.split(","):
        for n in part.split("-"):
            if not (1 <= int(n) <= 65535):
                return False
    return True


def _max_hosts():
    try:
        v = int(os.environ.get("REDVECTOR_SCAN_MAX_HOSTS", "256"))
    except (TypeError, ValueError):
        return 256
    return v if v > 0 else 256


def _hostnames_allowed():
    """Hostname targets are DISABLED by default (IP-only) for the initial lab
    test, until DNS-rebinding / TOCTOU risk is addressed. Opt in explicitly."""
    return (os.environ.get("REDVECTOR_SCAN_ALLOW_HOSTNAMES", "") or "").strip().lower() \
        in ("1", "true", "yes", "on")


def _load_scope():
    """Approved scope from REDVECTOR_SCAN_SCOPE and/or REDVECTOR_SCAN_SCOPE_FILE.
    Returns {'nets':[...], 'names':{...}} or None (fail closed) when missing or
    invalid. '#' starts a comment; entries are IPs, CIDRs, or hostnames."""
    entries = []
    fpath = os.environ.get("REDVECTOR_SCAN_SCOPE_FILE", "").strip()
    if fpath:
        try:
            with open(fpath, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.split("#", 1)[0].strip()
                    if line:
                        entries.append(line)
        except OSError:
            return None  # configured but unreadable -> fail closed
    raw = os.environ.get("REDVECTOR_SCAN_SCOPE", "")
    for tok in raw.replace(",", " ").split():
        tok = tok.split("#", 1)[0].strip()
        if tok:
            entries.append(tok)
    if not entries:
        return None
    nets, names = [], set()
    for e in entries:
        try:
            nets.append(ipaddress.ip_network(e, strict=False))
            continue
        except ValueError:
            pass
        if _valid_hostname(e):
            names.add(e.lower())
        else:
            return None  # invalid scope entry -> fail closed
    return {"nets": nets, "names": names}


def _net_contains(net, ip_obj):
    try:
        return ip_obj in net
    except TypeError:
        return False


def _cidr_subnet_of(child, nets):
    for n in nets:
        try:
            if child.subnet_of(n):
                return True
        except (TypeError, ValueError):
            continue
    return False


def _resolve_host(name):
    try:
        infos = socket.getaddrinfo(name, None)
    except (socket.gaierror, OSError):
        return []
    out = set()
    for fam, _, _, _, sockaddr in infos:
        out.add(sockaddr[0])
    return sorted(out)


def _classify_target(target):
    if not _TARGET_CHARS.match(target):
        return ("invalid", None)
    try:
        return ("ip", ipaddress.ip_address(target))
    except ValueError:
        pass
    if "/" in target:
        try:
            return ("cidr", ipaddress.ip_network(target, strict=False))
        except ValueError:
            return ("invalid", None)
    if _valid_hostname(target):
        return ("hostname", target)
    return ("invalid", None)


def _target_in_scope(kind, value, target, scope):
    nets = scope["nets"]
    if kind == "ip":
        return any(_net_contains(n, value) for n in nets)
    if kind == "cidr":
        return _cidr_subnet_of(value, nets)
    if kind == "hostname":
        if target.lower() not in scope["names"]:
            return False
        ips = _resolve_host(target)
        if not ips:
            return False
        for ip in ips:
            obj = ipaddress.ip_address(ip)
            if not any(_net_contains(n, obj) for n in nets):
                return False
        return True
    return False


def tool_scan_tcp_ports(params):
    scope = _load_scope()
    if scope is None:
        return _reject("config", "approved scan scope is not configured or is invalid; "
                                 "set REDVECTOR_SCAN_SCOPE or REDVECTOR_SCAN_SCOPE_FILE")
    if params.get("authorized") is not True:
        return _reject("authorization", "explicit authorization required: set 'authorized': true "
                                        "(scope is still enforced technically)")
    target = params.get("target", "")
    if not isinstance(target, str) or not target.strip():
        return _reject("validation", "'target' is required")
    target = target.strip()
    ports = params.get("ports", "")
    if ports:
        if not isinstance(ports, str) or not _valid_ports(ports):
            return _reject("validation", "invalid 'ports' (use digits, commas, hyphens; 1-65535)")
    kind, value = _classify_target(target)
    if kind == "invalid":
        return _reject("validation", "invalid target syntax (expect IPv4/IPv6/hostname/CIDR)")
    if kind == "hostname" and not _hostnames_allowed():
        return _reject("policy", "hostname targets are disabled (IP-only mode for initial lab "
                                 "testing); set REDVECTOR_SCAN_ALLOW_HOSTNAMES=1 only after "
                                 "DNS-rebinding/TOCTOU review")
    if kind == "cidr" and value.num_addresses > _max_hosts():
        return _reject("scope", "CIDR range too large (%d addresses > limit %d)"
                       % (value.num_addresses, _max_hosts()))
    if not _target_in_scope(kind, value, target, scope):
        return _reject("scope", "target is outside the approved scan scope")
    token = (os.environ.get("REDVECTOR_API_TOKEN", "") or "").strip()
    if not token or token == "redvector-dev-token":
        return _reject("backend-auth-config",
                       "REDVECTOR_API_TOKEN is not configured (refusing dev-token fallback)")
    payload = {"target": target, "scan_type": _SCAN_TYPE, "ports": ports,
               "additional_args": _ADDITIONAL_ARGS, "use_recovery": _USE_RECOVERY}
    ok, status, text = _loopback_post(_BACKEND_ENDPOINT, payload, token)
    return _map_scan_response(target, kind, ports, ok, status, text)


def _map_scan_response(target, kind, ports, ok, status, text):
    base = {"requested_target": target, "target_kind": kind,
            "ports_requested": ports or "default", "authorized": True}
    execu = {"tool": "scan_tcp_ports", "request_authorized": True, "backend_request": "sent"}
    if not ok:
        base.update({"status": "backend_unreachable" if text == "unreachable" else "backend_error",
                     "evidence": "no-backend-response", "detail": text,
                     "open_ports": [], "services": [], "execution": execu})
        return base
    if status == 401:
        base.update({"status": "backend_auth_failed", "evidence": "backend-response",
                     "http_status": 401, "open_ports": [], "services": [],
                     "detail": "backend rejected credentials (authentication failure, not authorization)",
                     "execution": dict(execu, backend_request="rejected-auth")})
        return base
    if status != 200:
        base.update({"status": "backend_error", "evidence": "backend-response",
                     "http_status": status, "open_ports": [], "services": [],
                     "execution": dict(execu, backend_request="accepted")})
        return base
    body = _health_json(text)
    if body is None:
        base.update({"status": "backend_malformed_response", "evidence": "backend-response",
                     "http_status": 200, "open_ports": [], "services": [],
                     "detail": "backend response was not a valid JSON object",
                     "execution": dict(execu, backend_request="accepted")})
        return base
    parsed = body.get("parsed") if isinstance(body.get("parsed"), dict) else {}
    open_ports = parsed.get("open_ports") if isinstance(parsed.get("open_ports"), list) else []
    services = parsed.get("services") if isinstance(parsed.get("services"), list) else []
    timed_out = bool(body.get("timed_out"))
    partial = bool(body.get("partial_results"))
    succ = body.get("success")
    if timed_out:
        st = "scan_timed_out"
    elif succ is True:
        st = "completed_partial" if partial else "completed"
    elif succ is False:
        st = "scan_failed"
    else:
        st = "completed_unknown"
    warnings = []
    if body.get("error"):
        warnings.append(str(body.get("error"))[:300])
    base.update({
        "status": st, "evidence": "backend-execution",
        "open_ports": open_ports, "services": services,
        "os_detection": parsed.get("os_detection", ""),
        "scan_summary": parsed.get("scan_summary", ""),
        "backend": {"success": succ, "return_code": body.get("return_code"),
                    "execution_time": body.get("execution_time"),
                    "timed_out": timed_out, "partial_results": partial},
        "warnings": warnings,
        "execution": dict(execu, backend_request="accepted", scan=st),
    })
    return base


# --------------------------------------------------------------------------
# Tool definitions / schemas
# --------------------------------------------------------------------------
_EMPTY_INPUT = {"type": "object", "properties": {}, "additionalProperties": False}
_READONLY = {"readOnlyHint": True, "destructiveHint": False, "openWorldHint": False}
_SCAN_INPUT = {
    "type": "object",
    "properties": {
        "target": {"type": "string",
                   "description": "IPv4/IPv6 address, hostname, or CIDR to scan. "
                                  "Must fall within the approved scan scope."},
        "ports": {"type": "string",
                  "description": "Optional TCP ports/ranges, e.g. '22,80,443' or '1-1024'. "
                                 "Digits, commas and hyphens only."},
        "authorized": {"type": "boolean",
                       "description": "Must be true to acknowledge the scan is authorized. "
                                      "Scope is still enforced technically regardless."},
    },
    "required": ["target", "authorized"],
    "additionalProperties": False,
}
_SCAN_ANNOTATIONS = {"readOnlyHint": False, "destructiveHint": False, "openWorldHint": True}

TOOL_DEFS = [
    {"name": "backend_health", "title": "RedVector backend health",
     "description": "Read-only check of whether the local RedVector backend is reachable and reports healthy.",
     "inputSchema": _EMPTY_INPUT, "annotations": _READONLY},
    {"name": "service_status", "title": "RedVector service status",
     "description": "Minimal, non-sensitive loopback reachability diagnostics for the local RedVector service.",
     "inputSchema": _EMPTY_INPUT, "annotations": _READONLY},
    {"name": "backend_version", "title": "RedVector backend version",
     "description": "Return the running RedVector backend's self-reported version, or 'unknown' if unavailable.",
     "inputSchema": _EMPTY_INPUT, "annotations": _READONLY},
    {"name": "scan_tcp_ports", "title": "RedVector authorized TCP port scan",
     "description": "Run an authorized TCP port and service/version scan via RedVector's existing backend "
                    "scanner. Enforces approved target scope; returns genuine backend results only.",
     "inputSchema": _SCAN_INPUT, "annotations": _SCAN_ANNOTATIONS},
]


# --------------------------------------------------------------------------
# Minimal MCP stdio transport (newline-delimited JSON-RPC 2.0)
# --------------------------------------------------------------------------
def _send(obj):
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def _result(mid, result):
    _send({"jsonrpc": "2.0", "id": mid, "result": result})


def _error(mid, code, message):
    _send({"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": message}})


def _ok_result(mid, data):
    _result(mid, {"content": [{"type": "text", "text": json.dumps(data, separators=(",", ":"))}],
                  "structuredContent": data})


def _handle_tools_call(mid, params):
    name = (params or {}).get("name")
    if name not in ALLOWED_TOOLS:
        _error(mid, -32601, "tool not allowed")
        return
    if name == "scan_tcp_ports":
        args = (params or {}).get("arguments")
        if args is None:
            args = (params or {}).get("input") or {}
        if not isinstance(args, dict):
            _error(mid, -32602, "invalid params: 'arguments' must be an object")
            return
        extra = set(args) - _SCAN_ARGS
        if extra:
            _error(mid, -32602, "unsupported argument(s): " + ",".join(sorted(extra)))
            return
        try:
            data = tool_scan_tcp_ports(args)
        except Exception:
            _result(mid, {"isError": True,
                          "content": [{"type": "text", "text": "scan adapter error"}]})
            return
        _ok_result(mid, data)
        return
    # diagnostics: preserve v0.1.0 behavior (ignore any arguments)
    try:
        data = DIAG_HANDLERS[name]()
    except Exception:
        _result(mid, {"isError": True,
                      "content": [{"type": "text", "text": "diagnostic error"}]})
        return
    _ok_result(mid, data)


def main():
    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except (ValueError, TypeError):
            _error(None, -32700, "parse error")
            continue
        if not isinstance(msg, dict):
            continue
        method = msg.get("method")
        mid = msg.get("id")
        if method is None:
            continue
        if method == "initialize":
            params = msg.get("params") or {}
            requested = params.get("protocolVersion")
            protocol = requested if isinstance(requested, str) else DEFAULT_PROTOCOL_VERSION
            _result(mid, {"protocolVersion": protocol, "capabilities": {"tools": {}},
                          "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION}})
        elif method == "notifications/initialized":
            continue
        elif method == "tools/list":
            _result(mid, {"tools": TOOL_DEFS})
        elif method == "tools/call":
            _handle_tools_call(mid, msg.get("params"))
        elif method == "ping":
            _result(mid, {})
        elif mid is not None:
            _error(mid, -32601, "method not found")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError, BrokenPipeError):
        pass
