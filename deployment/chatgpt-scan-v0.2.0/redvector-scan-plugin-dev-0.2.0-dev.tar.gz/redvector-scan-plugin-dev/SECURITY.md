# RedVector Scan Plugin v0.2.0-dev — security controls & residual risks

## Enforced controls (in code, fail-closed)
1. **Exact-name allowlist** of 4 tools; everything else → `-32601`. No
   exploitation/credential/persistence/privesc/pivot/destructive/shell tools.
2. **No local execution:** the adapter imports no `subprocess`/`os.system`;
   verified by `tests/test_scan_plugin.py` (AST check). It only performs HTTP to
   a validated loopback backend — it does **not** run nmap or any second engine.
3. **Scope gate on every scan**, in order, each fail-closed:
   config present → explicit `authorized:true` → strict target syntax (rejects
   spaces & shell/argument metacharacters) → CIDR size limit → scope membership →
   backend token present. A natural-language "authorized" claim cannot bypass the
   technical scope check: the target must be inside the configured scope.
4. **DNS-rebinding guard:** a hostname target must be name-allowlisted **and**
   every resolved IP must fall inside an approved IP/CIDR entry; unresolvable or
   out-of-scope resolution → reject.
5. **Backend auth preserved & required:** scans send the existing `Bearer` token
   (from `REDVECTOR_API_TOKEN`); the well-known `redvector-dev-token` fallback is
   refused. Authentication failures (401) are reported distinctly from
   authorization/scope rejections.
6. **Loopback-only backend connection**, no redirects followed, bounded timeout.
7. **No credential leakage:** the token is sent only as a request header, never
   logged or returned; verified by test (token absent from adapter stdout).
8. **Genuine results only:** ports/services come solely from the backend's
   `parsed` output; nothing is fabricated. Execution state is reported honestly
   (`completed` / `completed_partial` / `scan_timed_out` / `scan_failed` /
   `backend_auth_failed` / `backend_error` / `backend_unreachable` /
   `backend_malformed_response` / `rejected`).
9. **No production mutation:** does not start/stop/restart the backend, install
   anything, or modify existing RedVector/Claude/ChatGPT components.

## Residual risks (documented, not remediated here)
- **TOCTOU / DNS rebinding:** for the **initial lab test this is avoided** —
  hostname targets are **disabled by default** (IP-only mode); only IP addresses
  and IP CIDRs are accepted, which are not subject to DNS rebinding. Hostnames
  can be enabled with `REDVECTOR_SCAN_ALLOW_HOSTNAMES=1`; in that mode scope is
  enforced at request time using current resolution, but the adapter passes the
  original target to the backend which re-resolves it, so a hostname's DNS could
  change between the two resolutions (residual TOCTOU). Enable hostnames only
  after that review; a stronger fix (pinning an in-scope IP) would "substitute
  the target" and needs separate approval.
- **Backend-side controls unchanged:** the backend still has no global target
  authorization, a dev-token fallback, and permissive CORS (Stage 5B F-1..F-6).
  This plugin does not weaken them, but it also cannot fix them without backend
  changes (out of scope). If secure authorization required backend changes, that
  portion would be stopped and reported — it did not; the gate lives entirely in
  the adapter.
- **Scope correctness is operator-owned:** an overly broad `REDVECTOR_SCAN_SCOPE`
  authorizes broad scanning. Keep scope minimal and lab-only.
- **Runtime unverified:** no live scan has been performed; backend reachability,
  `nmap` availability, and real responses must be verified on Kali under separate
  approval.
