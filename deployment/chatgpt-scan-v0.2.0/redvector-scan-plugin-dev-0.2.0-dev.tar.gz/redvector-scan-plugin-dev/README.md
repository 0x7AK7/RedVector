# RedVector Scan Plugin v0.2.0-dev (isolated development build)

Additive ChatGPT Desktop MCP plugin. Preserves the three installed diagnostic
tools unchanged and adds **one** reviewed capability, `scan_tcp_ports`, that
reuses RedVector's **existing** backend scanner (`POST /api/tools/nmap`). The
adapter never runs nmap or any shell itself — it only calls the authenticated
loopback backend. **Not installed, activated, or deployed by this package.**

## Tools
| tool | type | notes |
|---|---|---|
| `backend_health` | read-only | identical to v0.1.0 |
| `service_status` | read-only | identical to v0.1.0 |
| `backend_version` | read-only | identical to v0.1.0 |
| `scan_tcp_ports` | active scan (scope-gated) | **new**; input `{target, authorized, ports?}` |

## Required environment (nothing hardcoded; no secrets in files)
| variable | purpose | required |
|---|---|---|
| `REDVECTOR_HOST` | backend host (loopback only) | optional (default `127.0.0.1`) |
| `REDVECTOR_PORT` | backend port | yes (no default — fail closed) |
| `REDVECTOR_API_TOKEN` | backend bearer token | yes for scans; dev-token fallback refused |
| `REDVECTOR_SCAN_SCOPE` | approved targets (space/comma IPs, CIDRs, hostnames) | yes* |
| `REDVECTOR_SCAN_SCOPE_FILE` | file of approved targets (one per line) | yes* |
| `REDVECTOR_SCAN_MAX_HOSTS` | CIDR size limit (default 256) | optional |
| `REDVECTOR_SCAN_ALLOW_HOSTNAMES` | allow hostname targets (default off → IP-only) | optional |
| `REDVECTOR_SCAN_TIMEOUT` | per-scan timeout seconds (default 120) | optional |
| `REDVECTOR_DIAG_TIMEOUT` | diagnostics timeout (default 3) | optional |

\*At least one scope source must be set and valid, or every scan is refused
(fail closed). The diagnostics' env behavior is unchanged from v0.1.0. Provide
the token and scope through ChatGPT Desktop's plugin environment / a secured
file — never in source, manifests, fixtures, logs, or reports.

## Run the tests (isolated, no real scans)
```bash
python3 tests/test_scan_plugin.py   # mock backend fixture; 52 checks
```

## Deployment plan (separate explicit approval required — do NOT run now)
1. **Files to deploy:** `plugin.json`, `mcp.json`, `adapter/redvector_scan_adapter.py`
   (config/ and tests/ are not required at runtime).
2. **Env:** set `REDVECTOR_PORT`, `REDVECTOR_API_TOKEN`, and a scope source via
   ChatGPT Desktop's plugin configuration (approved secure source).
3. **Scope:** copy `config/scan_scope.example.conf`, replace with authorized lab
   targets, point `REDVECTOR_SCAN_SCOPE_FILE` at it (or set `REDVECTOR_SCAN_SCOPE`).
4. **Validate manifests:** `python3 -m json.tool plugin.json` / `mcp.json`.
5. **Install** as a NEW plugin (new name+version `redvector-scan-plugin-dev`
   `0.2.0-dev`) via the supported Plugin Creator / personal marketplace flow —
   do **not** overwrite v0.1.0 and do **not** edit the versioned plugin cache by hand.
6. **Tool discovery:** confirm ChatGPT lists exactly the 4 tools.
7. **Backend connectivity:** run `backend_health` / `backend_version`.
8. **Mock acceptance:** re-run `tests/test_scan_plugin.py`.
9. **Authorized lab scan:** only against in-scope lab targets, with the operator's
   explicit authorization, as a separately approved step. **For the initial lab
   test, use explicit IP addresses only** — hostname targets are disabled by
   default (IP-only mode) and should be enabled with
   `REDVECTOR_SCAN_ALLOW_HOSTNAMES=1` only after the DNS-rebinding/TOCTOU review.

## Rollback plan
- The installed **v0.1.0 diagnostic plugin remains untouched** and is the rollback
  baseline. To revert, **disable/remove the `redvector-scan-plugin-dev` entry**
  through the supported plugin-management UI; v0.1.0 continues serving the three
  diagnostics. Do not hand-delete plugin cache directories as a routine rollback,
  and do not modify unrelated plugins or desktop configuration.

## Runtime prerequisites (verify on Kali, separately)
- RedVector backend running and reachable on the configured loopback port.
- `nmap` installed on the backend host (the adapter never invokes it directly).
- A valid non-default `REDVECTOR_API_TOKEN` and an authorized scope.

See `SECURITY.md` for enforced controls and residual risks.
